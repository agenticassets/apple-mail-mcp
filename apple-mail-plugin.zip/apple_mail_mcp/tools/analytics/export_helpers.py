"""Shared helpers for bounded email export."""

from collections.abc import Callable

from apple_mail_mcp.backend.base import ToolError, serialize_tool_error
from apple_mail_mcp.bounded_scan import iter_id_chunks
from apple_mail_mcp.core import AppleScriptTimeout, escape_applescript, normalize_message_ids, run_applescript
from apple_mail_mcp.core.replied import sent_mailbox_resolve_script
from apple_mail_mcp.tools.analytics.correspondent_matching import (
    correspondent_match_block,
    correspondent_match_handler,
    correspondent_read_failure_count,
    correspondent_read_failure_init,
    correspondent_read_failure_report,
)
from apple_mail_mcp.tools.analytics.export_failure_reporting import (
    ID_EXPORT_RETRY_HINT,
    PAGE_EXPORT_RETRY_HINT,
    correspondent_retry_hint,
    export_count_report,
    export_failure_arm,
    export_failure_init,
    export_result_banner,
    export_write_recorded,
)
from apple_mail_mcp.tools.analytics.export_formatting import (
    attachment_bundle_save_block,
    attachment_bundle_setup_block,
    deterministic_newest_first_block,
    export_content_block,
    mailbox_lookup_block,
    sanitize_delimiter_block,
)


def message_ids_by_mailbox(records: list[dict[str, object]], *, default_mailbox: str) -> dict[str, list[str]]:
    grouped: dict[str, list[str]] = {}
    seen: set[tuple[str, str]] = set()
    for record in records:
        normalized = normalize_message_ids([str(record.get("message_id", "")).strip()])
        if not normalized:
            continue
        mailbox_name = str(record.get("mailbox", "") or default_mailbox).strip() or default_mailbox
        key = (mailbox_name, normalized[0])
        if key in seen:
            continue
        seen.add(key)
        grouped.setdefault(mailbox_name, []).append(normalized[0])
    return grouped


def unbounded_export_error(account: str) -> str:
    return serialize_tool_error(
        ToolError(
            code="UNBOUNDED_SCAN_REQUIRED",
            message="export_emails refuses filtered export without a bounded date window",
            remediation={
                "preferred": "Pass recent_days=7 or date_from='YYYY-MM-DD'",
                "exact_selector": "message_ids",
                "discovery": "search_emails(..., recent_days=..., limit=...)",
                "account": account,
            },
        )
    )


def build_exact_message_export_script(
    *,
    safe_account: str,
    mailbox: str,
    safe_format: str,
    safe_save_dir: str,
    message_ids: list[str],
    include_attachments: bool = False,
    max_attachment_bytes: int = 25 * 1024 * 1024,
    max_total_attachment_bytes: int = 100 * 1024 * 1024,
) -> str:
    requested_ids = ", ".join(message_ids)
    return f'''
            tell application "Mail"
                set outputText to "EXPORTING MESSAGES BY ID" & return & return
                set requestedIds to {{{requested_ids}}}
                set exportCount to 0
                set exportAttachmentBytes to 0
                {export_failure_init()}

                try
                    set targetAccount to account "{safe_account}"
                    {mailbox_lookup_block(mailbox)}

                    set exportDir to "{safe_save_dir}/message_id_export"
                    do shell script "mkdir -p " & quoted form of exportDir

                    repeat with requestedId in requestedIds
                        set requestedIdText to requestedId as string
                        set matchedMessages to (every message of targetMailbox whose id is requestedId)
                        set foundMessage to missing value
                        if (count of matchedMessages) > 0 then
                            set foundMessage to item 1 of matchedMessages
                        end if

                        if foundMessage is not missing value then
                            try
                                set aMessage to foundMessage
                                set messageSubject to subject of foundMessage
                                set messageSender to sender of foundMessage
                                set messageDate to date received of foundMessage
                                set messageContent to content of foundMessage

                                set safeSubject to messageSubject
                                {sanitize_delimiter_block("safeSubject")}

                                set exportCount to exportCount + 1
                                set fileName to exportCount & "_" & requestedIdText & "_" & safeSubject & ".{safe_format}"
                                set filePath to exportDir & "/" & fileName
                                {attachment_bundle_setup_block(include_attachments=include_attachments)}

                                {export_content_block(safe_format)}

                                set fileRef to open for access POSIX file filePath with write permission
                                set eof of fileRef to 0
                                write exportContent to fileRef as «class utf8»
                                close access fileRef
                                {export_write_recorded()}
                                {attachment_bundle_save_block(include_attachments=include_attachments, max_attachment_bytes=max_attachment_bytes, max_total_attachment_bytes=max_total_attachment_bytes)}

                                set outputText to outputText & "✓ Exported message_id " & requestedIdText & ": " & messageSubject & return
                            {export_failure_arm(id_var="requestedIdText")}
                            end try
                        else
                            set outputText to outputText & "⚠ No email found for message_id " & requestedIdText & return
                        end if
                    end repeat

                    set outputText to outputText & return
                    {export_count_report(retry_hint=ID_EXPORT_RETRY_HINT)}
                    set outputText to outputText & "Location: " & exportDir & return
                on error errMsg
                    return "Error: " & errMsg
                end try

                return outputText
            end tell
            '''


def build_entire_mailbox_export_script(
    *,
    safe_account: str,
    mailbox: str,
    safe_format: str,
    safe_save_dir: str,
    max_emails: int,
    offset: int,
    sort: str,
    date_setup: str,
    date_filter: str,
    include_attachments: bool = False,
    max_attachment_bytes: int = 25 * 1024 * 1024,
    max_total_attachment_bytes: int = 100 * 1024 * 1024,
) -> str:
    """Bounded ``messages pageStart thru pageEnd`` page-slice export.

    Never binds the full ``messages of targetMailbox``. ``date_filter`` runs
    WITHIN the page window, so out-of-range messages still count against
    the page but are skipped from the on-disk export.

    Paging here is positional: the next page starts at ``offset + max_emails``
    regardless of how many messages were written, so a per-message failure
    cannot desynchronize it. The failure is still reported (id + error + a
    ``PARTIAL:`` line) so the caller can re-export that id rather than
    discovering the gap on disk.
    """
    safe_mailbox = escape_applescript(mailbox)
    return f'''
    tell application "Mail"
        set outputText to "EXPORTING MAILBOX" & return & return
        {date_setup}

        try
            set targetAccount to account "{safe_account}"
            {mailbox_lookup_block(mailbox)}

            -- Bind only the requested page window; never the full message list.
            set messageCount to count of messages of targetMailbox
            set pageStart to {offset} + 1
            set pageEnd to {offset} + {max_emails}
            if pageEnd > messageCount then set pageEnd to messageCount
            set exportCount to 0
            set exportAttachmentBytes to 0
            {export_failure_init()}

            -- Create export directory
            set exportDir to "{safe_save_dir}/{safe_mailbox}_export"
            do shell script "mkdir -p " & quoted form of exportDir

            if pageStart <= messageCount and pageStart <= pageEnd then
                set pageMessages to messages pageStart thru pageEnd of targetMailbox
                -- ``newest_first`` and compatibility alias ``date_desc`` are
                -- both applied as descending received-date order.
                if "{sort}" is "newest_first" or "{sort}" is "date_desc" then
                    {deterministic_newest_first_block()}
                end if

                repeat with aMessage in pageMessages
                    try
                        set messageDate to date received of aMessage
                        set shouldExport to true
                        {date_filter}
                        if shouldExport then
                            set messageSubject to subject of aMessage
                            set messageSender to sender of aMessage
                            set messageContent to content of aMessage
                            set messageId to id of aMessage

                            -- Create safe filename with index
                            set exportCount to exportCount + 1
                            set fileName to exportCount & "_" & messageSubject & ".{safe_format}"

                            -- Remove unsafe characters
                            {sanitize_delimiter_block("fileName")}

                            set filePath to exportDir & "/" & fileName
                            {attachment_bundle_setup_block(include_attachments=include_attachments)}

                            {export_content_block(safe_format)}

                            -- Write to file
                            set fileRef to open for access POSIX file filePath with write permission
                            set eof of fileRef to 0
                            write exportContent to fileRef as «class utf8»
                            close access fileRef
                            {export_write_recorded()}
                            {attachment_bundle_save_block(include_attachments=include_attachments, max_attachment_bytes=max_attachment_bytes, max_total_attachment_bytes=max_total_attachment_bytes)}
                            set outputText to outputText & "Exported message_id: " & (messageId as string) & return
                        end if

                    {export_failure_arm()}
                    end try
                end repeat
            end if

            {export_result_banner(ok_text="✓ Mailbox exported successfully!", warn_text="⚠ Mailbox exported with errors")}
            set outputText to outputText & "Mailbox: {safe_mailbox}" & return
            set outputText to outputText & "Total emails in mailbox: " & messageCount & return
            set outputText to outputText & "Offset: {offset}" & return
            {export_count_report(retry_hint=PAGE_EXPORT_RETRY_HINT)}
            set outputText to outputText & "(bounded page: offset={offset}, max_emails={max_emails})" & return
            set outputText to outputText & "Location: " & exportDir & return

        on error errMsg
            return "Error: " & errMsg
        end try

        return outputText
    end tell
    '''


def build_multi_mailbox_id_export_script(
    *,
    safe_account: str,
    candidate_mailboxes: list[str],
    safe_format: str,
    safe_save_dir: str,
    message_ids: list[str],
    include_attachments: bool = False,
    max_attachment_bytes: int = 25 * 1024 * 1024,
    max_total_attachment_bytes: int = 100 * 1024 * 1024,
) -> str:
    """Export ids across a fixed candidate mailbox list; never opens "All Mail".

    Tries each ``candidate_mailboxes`` name directly (``INBOX`` falls back to
    ``Inbox``), keeps the ones that open, then id-looks-up each requested id
    across them (first match wins) via the accepted ``whose id is`` pattern
    (see ``search/by_id.py``). Gmail reports a thread message's container as
    the virtual, unopenable "All Mail" mailbox, so this never trusts that name.
    """
    requested_ids = ", ".join(message_ids)
    open_blocks: list[str] = []
    for index, name in enumerate(candidate_mailboxes, start=1):
        safe_name = escape_applescript(name)
        var_name = f"mb{index}"
        inbox_fallback = ""
        if name.strip().upper() == "INBOX":
            inbox_fallback = f'''
                    if "{safe_name}" is "INBOX" then
                        try
                            set {var_name} to mailbox "Inbox" of targetAccount
                            set end of openMailboxes to {var_name}
                        end try
                    end if'''
        open_blocks.append(f'''
                try
                    set {var_name} to mailbox "{safe_name}" of targetAccount
                    set end of openMailboxes to {var_name}
                on error{inbox_fallback}
                end try''')
    open_section = "\n".join(open_blocks)

    return f'''
    tell application "Mail"
        set outputText to "" & return
        set requestedIds to {{{requested_ids}}}
        set openMailboxes to {{}}
        set exportCount to 0
        set exportAttachmentBytes to 0
        {export_failure_init()}

        try
            set targetAccount to account "{safe_account}"
            {open_section}

            set exportDir to "{safe_save_dir}/thread_export"
            do shell script "mkdir -p " & quoted form of exportDir

            repeat with requestedId in requestedIds
                set requestedIdText to requestedId as string
                set foundMessage to missing value
                repeat with mb in openMailboxes
                    try
                        set matchedMessages to (every message of mb whose id is requestedId)
                        if (count of matchedMessages) > 0 then
                            set foundMessage to item 1 of matchedMessages
                            exit repeat
                        end if
                    end try
                end repeat

                if foundMessage is not missing value then
                    try
                        set aMessage to foundMessage
                        set messageSubject to subject of foundMessage
                        set messageSender to sender of foundMessage
                        set messageDate to date received of foundMessage
                        set messageContent to content of foundMessage

                        set safeSubject to messageSubject
                        {sanitize_delimiter_block("safeSubject")}

                        set exportCount to exportCount + 1
                        set fileName to exportCount & "_" & requestedIdText & "_" & safeSubject & ".{safe_format}"
                        set filePath to exportDir & "/" & fileName
                        {attachment_bundle_setup_block(include_attachments=include_attachments)}

                        {export_content_block(safe_format)}

                        set fileRef to open for access POSIX file filePath with write permission
                        set eof of fileRef to 0
                        write exportContent to fileRef as «class utf8»
                        close access fileRef
                        {export_write_recorded()}
                        {attachment_bundle_save_block(include_attachments=include_attachments, max_attachment_bytes=max_attachment_bytes, max_total_attachment_bytes=max_total_attachment_bytes)}

                        set outputText to outputText & "✓ Exported message_id " & requestedIdText & ": " & messageSubject & return
                    {export_failure_arm(id_var="requestedIdText")}
                    end try
                else
                    set outputText to outputText & "⚠ No email found for message_id " & requestedIdText & return
                end if
            end repeat

            set outputText to outputText & return
            {export_count_report(retry_hint=ID_EXPORT_RETRY_HINT)}
            set outputText to outputText & "Location: " & exportDir & return
        on error errMsg
            return "Error: " & errMsg
        end try

        return outputText
    end tell
    '''


def run_multi_mailbox_id_export(
    *,
    account: str,
    safe_account: str,
    candidate_mailboxes: list[str],
    safe_format: str,
    safe_save_dir: str,
    message_ids: list[str],
    include_attachments: bool,
    max_attachment_bytes: int,
    max_total_attachment_bytes: int,
    timeout: int | None,
    runner: Callable[[str, int | None], str] = run_applescript,
) -> str:
    """Chunked wrapper around ``build_multi_mailbox_id_export_script``.

    Mirrors :func:`run_message_id_export`, scanning a fixed candidate
    mailbox list per id instead of a caller-supplied "All Mail" mailbox.
    """
    normalized_ids = normalize_message_ids(message_ids)
    if not normalized_ids:
        return "Error: message ids must contain one or more numeric Mail ids"

    chunk_results: list[str] = []
    for chunk in iter_id_chunks(normalized_ids):
        script = build_multi_mailbox_id_export_script(
            safe_account=safe_account,
            candidate_mailboxes=candidate_mailboxes,
            safe_format=safe_format,
            safe_save_dir=safe_save_dir,
            message_ids=chunk,
            include_attachments=include_attachments,
            max_attachment_bytes=max_attachment_bytes,
            max_total_attachment_bytes=max_total_attachment_bytes,
        )
        try:
            chunk_results.append(runner(script, timeout if timeout is not None else 120))
        except AppleScriptTimeout:
            return f"Error: AppleScript timed out while exporting message_ids for '{account}'"

    return "\n\n".join(chunk_results)


def build_correspondent_export_script(
    *,
    safe_account: str,
    safe_email_address: str,
    safe_format: str,
    safe_save_dir: str,
    mailbox: str,
    scan_upper_bound: int,
    max_emails: int,
    offset: int,
    include_sent: bool,
    date_setup: str,
    date_filter: str,
    include_attachments: bool = False,
    max_attachment_bytes: int = 25 * 1024 * 1024,
    max_total_attachment_bytes: int = 100 * 1024 * 1024,
) -> str:
    sent_resolve = sent_mailbox_resolve_script("sentMailbox", "targetAccount")
    sent_append = ""
    if include_sent:
        sent_append = """
                    if sentMailbox is not missing value then set end of searchMailboxes to sentMailbox
        """
    return f'''
{correspondent_match_handler()}

        tell application "Mail"
            set outputText to "EXPORTING CORRESPONDENT" & return & return
            {date_setup}

            try
                set targetAccount to account "{safe_account}"
                {mailbox_lookup_block(mailbox)}
                {sent_resolve}
                set searchMailboxes to {{targetMailbox}}
                {sent_append}

                set exportDir to "{safe_save_dir}/correspondent_export"
                do shell script "mkdir -p " & quoted form of exportDir
                set totalExportCount to 0
                set globalMatchedCount to 0
                set exportAttachmentBytes to 0
                {export_failure_init()}
                {correspondent_read_failure_init()}

                repeat with currentMailbox in searchMailboxes
                    if exportHalted then exit repeat
                    if totalExportCount >= {max_emails} then exit repeat
                    set mailboxName to name of currentMailbox
                    set messageCount to count of messages of currentMailbox
                    if messageCount > {scan_upper_bound} then
                        set mailboxMessages to messages 1 thru {scan_upper_bound} of currentMailbox
                    else
                        set mailboxMessages to messages of currentMailbox
                    end if
                    set mailboxExportCount to 0

                    repeat with aMessage in mailboxMessages
                        if totalExportCount >= {max_emails} then exit repeat
                        set exportAttempted to false
                        try
                            set messageDate to date received of aMessage
                            {correspondent_match_block(safe_email_address)}
                            {date_filter}
                            {correspondent_read_failure_count()}
                            if shouldExport then
                                set globalMatchedCount to globalMatchedCount + 1
                                if globalMatchedCount > {offset} then
                                    set exportAttempted to true
                                    set messageSubject to subject of aMessage
                                    set messageSender to sender of aMessage
                                    set messageContent to content of aMessage

                                    set totalExportCount to totalExportCount + 1
                                    set fileName to totalExportCount & "_" & mailboxName & "_" & messageSubject & ".{safe_format}"
                                    {sanitize_delimiter_block("fileName")}
                                    set filePath to exportDir & "/" & fileName
                                    {attachment_bundle_setup_block(include_attachments=include_attachments)}

                                    {export_content_block(safe_format, include_mailbox=True)}

                                    set fileRef to open for access POSIX file filePath with write permission
                                    set eof of fileRef to 0
                                    write exportContent to fileRef as «class utf8»
                                    close access fileRef
                                    {export_write_recorded()}
                                    set mailboxExportCount to mailboxExportCount + 1
                                    {attachment_bundle_save_block(include_attachments=include_attachments, max_attachment_bytes=max_attachment_bytes, max_total_attachment_bytes=max_total_attachment_bytes)}
                                end if
                            end if
                        {export_failure_arm(halt=True)}
                        end try
                    end repeat

                    set outputText to outputText & mailboxName & ": exported " & mailboxExportCount & return
                end repeat

                set outputText to outputText & return & "Email address: {safe_email_address}" & return
                {export_count_report(retry_hint=correspondent_retry_hint(offset))}
                {correspondent_read_failure_report()}
                set outputText to outputText & "Location: " & exportDir & return
            on error errMsg
                return "Error: " & errMsg
            end try

            return outputText
        end tell
        '''


def run_message_id_export(
    *,
    account: str,
    safe_account: str,
    safe_format: str,
    safe_save_dir: str,
    ids_by_mailbox: dict[str, list[str]],
    include_attachments: bool,
    max_attachment_bytes: int,
    max_total_attachment_bytes: int,
    timeout: int | None,
    runner: Callable[[str, int | None], str] = run_applescript,
) -> str:
    chunk_results: list[str] = []
    invalid_ids: list[str] = []
    for mailbox_name, ids in ids_by_mailbox.items():
        raw_ids = [str(value).strip() for value in ids if str(value).strip()]
        normalized_ids = normalize_message_ids(raw_ids)
        invalid_ids.extend(value for value in raw_ids if not value.isdigit())
        if not normalized_ids:
            continue
        for chunk in iter_id_chunks(normalized_ids):
            script = build_exact_message_export_script(
                safe_account=safe_account,
                mailbox=mailbox_name,
                safe_format=safe_format,
                safe_save_dir=safe_save_dir,
                message_ids=chunk,
                include_attachments=include_attachments,
                max_attachment_bytes=max_attachment_bytes,
                max_total_attachment_bytes=max_total_attachment_bytes,
            )
            try:
                chunk_results.append(runner(script, timeout if timeout is not None else 120))
            except AppleScriptTimeout:
                return f"Error: AppleScript timed out while exporting message_ids for '{account}'"

    if invalid_ids and chunk_results:
        chunk_results.append(f"Ignored invalid message_ids: {', '.join(invalid_ids)}")
    if not chunk_results:
        return "Error: 'message_ids' must contain one or more numeric Mail ids"
    return "\n\n".join(chunk_results)
